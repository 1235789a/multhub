"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import type {
  GenerateRequest,
  GenerateResponse,
  ApiErrorResponse,
  ProjectType,
  VisualGoal,
  VisualStyle,
  ToneType,
  GeneratedContent,
  RecentGeneration,
} from "@/lib/web3-promo-image-factory/types";

const WORKFLOWS = [
  {
    id: "web3-launch-poster",
    name: "Web3 Launch Poster",
    description: "Launch poster prompt and visual direction for a small Web3 product.",
    icon: "🚀",
    defaultVisualGoal: "Launch Poster" as VisualGoal,
    defaultStyle: "Dark Crypto" as VisualStyle,
    defaultTone: "Professional" as ToneType,
  },
  {
    id: "telegram-bot-promo",
    name: "Telegram Bot Promo",
    description: "Promo visual brief for Telegram bots, automation tools, and crypto communities.",
    icon: "🤖",
    defaultVisualGoal: "Telegram Announcement Image" as VisualGoal,
    defaultStyle: "Clean Web3" as VisualStyle,
    defaultTone: "Community-first" as ToneType,
  },
  {
    id: "ai-agent-launch",
    name: "AI Agent Launch Visual",
    description: "Futuristic launch visual prompt for AI x Crypto agents.",
    icon: "🤖",
    defaultVisualGoal: "X Promo Image" as VisualGoal,
    defaultStyle: "Futuristic" as VisualStyle,
    defaultTone: "Professional" as ToneType,
  },
  {
    id: "crypto-dashboard-promo",
    name: "Crypto Dashboard Promo",
    description: "Clean dashboard promo brief for analytics tools and crypto SaaS.",
    icon: "📊",
    defaultVisualGoal: "X Promo Image" as VisualGoal,
    defaultStyle: "Premium Fintech" as VisualStyle,
    defaultTone: "Serious" as ToneType,
  },
  {
    id: "meme-visual-concept",
    name: "Meme Visual Concept",
    description: "Meme-friendly visual concepts without fake financial claims.",
    icon: "🐸",
    defaultVisualGoal: "Meme Image" as VisualGoal,
    defaultStyle: "Meme / Degen" as VisualStyle,
    defaultTone: "Funny" as ToneType,
  },
];

const PROJECT_TYPES: ProjectType[] = [
  "Meme Coin",
  "NFT Project",
  "AI Agent",
  "Telegram Bot",
  "DeFi Tool",
  "Web3 Tool",
  "Crypto Community",
];

const VISUAL_GOALS: VisualGoal[] = [
  "Launch Poster",
  "Meme Image",
  "X Promo Image",
  "Telegram Announcement Image",
  "Community Engagement Image",
  "Partnership Visual",
  "Airdrop Campaign Visual",
];

const STYLES: VisualStyle[] = [
  "Cyberpunk",
  "Clean Web3",
  "Meme / Degen",
  "Futuristic",
  "Premium Fintech",
  "Dark Crypto",
  "Cute Mascot",
];

const TONES: ToneType[] = [
  "Serious",
  "Funny",
  "Degen",
  "Professional",
  "Community-first",
];

const DEMO: GenerateRequest = {
  projectName: "ChainPup AI",
  projectType: "AI Agent",
  projectDescription:
    "An AI agent that tracks meme coin community signals, trending narratives, and early attention spikes across Twitter and Telegram.",
  visualGoal: "Launch Poster",
  style: "Dark Crypto",
  tone: "Community-first",
  keyMessage: "Most meme coins die when the community goes silent. ChainPup tracks attention before the chart moves.",
  brandColors: "",
  logoDescription: "",
  workflowId: "web3-launch-poster",
};

const STORAGE_KEY = "web3_promo_image_recent";
const MAX_RECENT = 10;

function loadRecent(): RecentGeneration[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    return JSON.parse(raw) as RecentGeneration[];
  } catch {
    return [];
  }
}

function saveRecent(items: RecentGeneration[]) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(items.slice(0, MAX_RECENT)));
  } catch {
    // ignore
  }
}

function addRecent(item: RecentGeneration) {
  const items = loadRecent();
  saveRecent([item, ...items.filter((r) => r.id !== item.id)]);
}

export default function Web3PromoImageFactoryClient() {
  const [workflowId, setWorkflowId] = useState<string>("web3-launch-poster");
  const [form, setForm] = useState<GenerateRequest>({
    projectName: "",
    projectType: "Meme Coin",
    projectDescription: "",
    visualGoal: "Launch Poster",
    style: "Dark Crypto",
    tone: "Community-first",
    keyMessage: "",
    brandColors: "",
    logoDescription: "",
    workflowId: "web3-launch-poster",
  });

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<GeneratedContent | null>(null);
  const [imageUrl, setImageUrl] = useState<string | null>(null);
  const [providerMode, setProviderMode] = useState<string>("prompt_only");
  const [copiedField, setCopiedField] = useState<string | null>(null);
  const [licenseKey, setLicenseKey] = useState("");
  const [visitorId, setVisitorId] = useState<string | null>(null);
  const [remainingUses, setRemainingUses] = useState<number | null>(null);
  const [totalQuota, setTotalQuota] = useState<number | null>(null);
  const [mode, setMode] = useState<"trial" | "license" | null>(null);
  const [showTrialLimit, setShowTrialLimit] = useState(false);
  const [recentGenerations, setRecentGenerations] = useState<RecentGeneration[]>([]);
  const [showRecent, setShowRecent] = useState(false);

  useEffect(() => {
    setRecentGenerations(loadRecent());
  }, []);

  const currentWorkflow = WORKFLOWS.find((w) => w.id === workflowId) ?? WORKFLOWS[0]!;

  const selectWorkflow = (id: string) => {
    setWorkflowId(id);
    const wf = WORKFLOWS.find((w) => w.id === id) ?? WORKFLOWS[0]!;
    setForm((prev) => ({
      ...prev,
      workflowId: id,
      visualGoal: wf.defaultVisualGoal,
      style: wf.defaultStyle,
      tone: wf.defaultTone,
    }));
  };

  const loadVisitorId = async () => {
    if (visitorId) return visitorId;
    try {
      const buf = new Uint8Array(16);
      crypto.getRandomValues(buf);
      const id = Array.from(buf)
        .map((b) => b.toString(16).padStart(2, "0"))
        .join("");
      setVisitorId(id);
      return id;
    } catch {
      const id = `fallback_${Date.now()}_${Math.random().toString(36).slice(2, 10)}`;
      setVisitorId(id);
      return id;
    }
  };

  const handleGenerate = async () => {
    setError(null);
    setLoading(true);
    setResult(null);
    setImageUrl(null);
    try {
      const vid = await loadVisitorId();
      const headers: Record<string, string> = {
        "Content-Type": "application/json",
        "X-Visitor-Id": vid,
      };
      if (licenseKey.trim()) {
        headers["X-License-Key"] = licenseKey.trim();
      }

      const payload = { ...form, workflowId };

      const res = await fetch("/api/web3-promo-image-factory/generate", {
        method: "POST",
        headers,
        body: JSON.stringify(payload),
      });

      const data = (await res.json()) as GenerateResponse | ApiErrorResponse;

      if (!res.ok) {
        if (res.status === 402) {
          setShowTrialLimit(true);
          setLoading(false);
          return;
        }
        const errData = data as ApiErrorResponse;
        throw new Error(errData.message || errData.error || "Generation failed");
      }

      const okData = data as GenerateResponse;
      setResult(okData.content);
      setImageUrl(okData.imageUrl ?? null);
      setProviderMode(okData.providerMode);
      setRemainingUses(
        okData.meta.licenseQuota - okData.meta.licenseUsage,
      );
      setTotalQuota(okData.meta.licenseQuota);
      setMode(okData.meta.mode);

      const recentItem: RecentGeneration = {
        id: `${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
        projectName: form.projectName,
        workflowId,
        workflowName: currentWorkflow.name,
        createdAt: new Date().toISOString(),
        imageUrl: okData.imageUrl,
        hasImage: !!okData.imageUrl,
      };
      addRecent(recentItem);
      setRecentGenerations(loadRecent());
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unknown error");
    } finally {
      setLoading(false);
    }
  };

  const copyToClipboard = async (text: string, field: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedField(field);
      setTimeout(() => setCopiedField(null), 2000);
    } catch {
      setError("Copy failed");
    }
  };

  const loadDemo = () => {
    selectWorkflow("web3-launch-poster");
    setForm(DEMO);
  };

  const restoreGeneration = (item: RecentGeneration) => {
    setWorkflowId(item.workflowId);
    setShowRecent(false);
    setError(null);
    if (item.imageUrl) {
      setImageUrl(item.imageUrl);
      setProviderMode("provider");
    } else {
      setImageUrl(null);
      setProviderMode("prompt_only");
    }
    setResult(null);
  };

  return (
    <main className="min-h-screen bg-black text-zinc-200">
      <div className="mx-auto max-w-6xl px-6 py-8 md:py-12">
        <Link
          href="/"
          className="inline-flex items-center text-sm text-zinc-500 hover:text-zinc-300 mb-6 transition-colors"
        >
          ← Back to Home
        </Link>

        <header className="mb-8">
          <div className="flex items-center gap-3 mb-3">
            <span className="text-3xl">🎨</span>
            <h1 className="text-2xl md:text-3xl font-bold text-white">
              Web3 Promo Image Factory
            </h1>
          </div>
          <p className="text-zinc-400 max-w-2xl">
            Generate prompt-ready promo visual packs for Web3 products. Pick a workflow
            template and get a structured visual pack: image prompt, negative prompt,
            visual brief, headline, caption, layout tips, and variants.
          </p>
          <p className="text-xs text-zinc-600 mt-2">
            Prompt-only mode. The tool works without an image provider. Connect an
            image provider later if you want generated image previews.
          </p>
        </header>

        <div className="space-y-6">
          {/* Workflow Selection */}
          <div className="bg-zinc-900/50 border border-zinc-800 rounded-xl p-5">
            <h2 className="text-sm font-semibold text-zinc-300 mb-2">
              Choose a workflow template
            </h2>
            <p className="text-xs text-zinc-500 mb-4">
              Start from a proven visual workflow instead of a blank prompt.
            </p>
            <div className="grid grid-cols-2 md:grid-cols-5 gap-3 mb-4">
              {WORKFLOWS.map((wf) => (
                <button
                  key={wf.id}
                  onClick={() => selectWorkflow(wf.id)}
                  className={`p-3 rounded-lg border text-left transition-all ${
                    workflowId === wf.id
                      ? "border-emerald-500 bg-emerald-500/10"
                      : "border-zinc-700 bg-black hover:border-zinc-600"
                  }`}
                >
                  <div className="text-xl mb-1">{wf.icon}</div>
                  <div className="text-xs font-medium text-zinc-200 leading-tight">
                    {wf.name}
                  </div>
                </button>
              ))}
            </div>
            <p className="text-xs text-zinc-500">
              Selected: <span className="text-emerald-400">{currentWorkflow.name}</span>
              {" — "}{currentWorkflow.description}
            </p>
          </div>

          {/* Project Form */}
          <div className="bg-zinc-900/50 border border-zinc-800 rounded-xl p-5">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-sm font-semibold text-zinc-300">
                Project Details
              </h2>
              <button
                onClick={loadDemo}
                className="text-xs text-emerald-400 hover:text-emerald-300 transition-colors"
              >
                Use Demo Project →
              </button>
            </div>
            <div className="space-y-4">
              <div>
                <label className="block text-xs text-zinc-500 mb-1.5">
                  Project Name *
                </label>
                <input
                  type="text"
                  value={form.projectName}
                  onChange={(e) =>
                    setForm({ ...form, projectName: e.target.value })
                  }
                  placeholder="e.g. ChainPup AI"
                  className="w-full bg-black border border-zinc-800 rounded-lg px-3 py-2 text-sm text-zinc-200 placeholder:text-zinc-600 focus:outline-none focus:border-zinc-600"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs text-zinc-500 mb-1.5">
                    Project Type
                  </label>
                  <select
                    value={form.projectType}
                    onChange={(e) =>
                      setForm({ ...form, projectType: e.target.value as ProjectType })
                    }
                    className="w-full bg-black border border-zinc-800 rounded-lg px-3 py-2 text-sm text-zinc-200 focus:outline-none focus:border-zinc-600"
                  >
                    {PROJECT_TYPES.map((t) => (
                      <option key={t} value={t}>{t}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs text-zinc-500 mb-1.5">
                    Visual Goal
                  </label>
                  <select
                    value={form.visualGoal}
                    onChange={(e) =>
                      setForm({ ...form, visualGoal: e.target.value as VisualGoal })
                    }
                    className="w-full bg-black border border-zinc-800 rounded-lg px-3 py-2 text-sm text-zinc-200 focus:outline-none focus:border-zinc-600"
                  >
                    {VISUAL_GOALS.map((g) => (
                      <option key={g} value={g}>{g}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs text-zinc-500 mb-1.5">
                  Project Description *
                </label>
                <textarea
                  value={form.projectDescription}
                  onChange={(e) =>
                    setForm({ ...form, projectDescription: e.target.value })
                  }
                  placeholder="What does your project do? What makes it unique?"
                  rows={3}
                  className="w-full bg-black border border-zinc-800 rounded-lg px-3 py-2 text-sm text-zinc-200 placeholder:text-zinc-600 focus:outline-none focus:border-zinc-600 resize-none"
                />
              </div>

              <div>
                <label className="block text-xs text-zinc-500 mb-1.5">
                  Key Message *
                </label>
                <input
                  type="text"
                  value={form.keyMessage}
                  onChange={(e) =>
                    setForm({ ...form, keyMessage: e.target.value })
                  }
                  placeholder="The main point or hook you want to convey"
                  className="w-full bg-black border border-zinc-800 rounded-lg px-3 py-2 text-sm text-zinc-200 placeholder:text-zinc-600 focus:outline-none focus:border-zinc-600"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs text-zinc-500 mb-1.5">
                    Style
                  </label>
                  <select
                    value={form.style}
                    onChange={(e) =>
                      setForm({ ...form, style: e.target.value as VisualStyle })
                    }
                    className="w-full bg-black border border-zinc-800 rounded-lg px-3 py-2 text-sm text-zinc-200 focus:outline-none focus:border-zinc-600"
                  >
                    {STYLES.map((s) => (
                      <option key={s} value={s}>{s}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs text-zinc-500 mb-1.5">
                    Tone
                  </label>
                  <select
                    value={form.tone}
                    onChange={(e) =>
                      setForm({ ...form, tone: e.target.value as ToneType })
                    }
                    className="w-full bg-black border border-zinc-800 rounded-lg px-3 py-2 text-sm text-zinc-200 focus:outline-none focus:border-zinc-600"
                  >
                    {TONES.map((t) => (
                      <option key={t} value={t}>{t}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs text-zinc-500 mb-1.5">
                  Brand Colors (optional)
                </label>
                <input
                  type="text"
                  value={form.brandColors ?? ""}
                  onChange={(e) =>
                    setForm({ ...form, brandColors: e.target.value })
                  }
                  placeholder="e.g. Black, Gold, Emerald Green"
                  className="w-full bg-black border border-zinc-800 rounded-lg px-3 py-2 text-sm text-zinc-200 placeholder:text-zinc-600 focus:outline-none focus:border-zinc-600"
                />
              </div>

              <div>
                <label className="block text-xs text-zinc-500 mb-1.5">
                  Logo Description (optional)
                </label>
                <input
                  type="text"
                  value={form.logoDescription ?? ""}
                  onChange={(e) =>
                    setForm({ ...form, logoDescription: e.target.value })
                  }
                  placeholder="Describe your logo if you have one"
                  className="w-full bg-black border border-zinc-800 rounded-lg px-3 py-2 text-sm text-zinc-200 placeholder:text-zinc-600 focus:outline-none focus:border-zinc-600"
                />
              </div>
            </div>

            <div className="mt-5 space-y-3">
              <button
                onClick={handleGenerate}
                disabled={
                  loading ||
                  !form.projectName ||
                  !form.projectDescription ||
                  !form.keyMessage
                }
                className="w-full bg-emerald-500 hover:bg-emerald-600 disabled:bg-zinc-800 disabled:text-zinc-600 text-black font-semibold py-2.5 rounded-lg transition-colors text-sm"
              >
                {loading ? "Generating..." : "🎨 Generate Visual Pack"}
              </button>
              <button
                onClick={loadDemo}
                disabled={loading}
                className="w-full border border-zinc-700 text-zinc-400 hover:text-zinc-200 hover:border-zinc-600 py-2 rounded-lg transition-colors text-xs"
              >
                Use Demo Project (ChainPup AI)
              </button>
            </div>
          </div>

          {/* License */}
          <div className="bg-zinc-900/50 border border-zinc-800 rounded-xl p-5">
            <div className="flex items-center justify-between mb-3">
              <h2 className="text-sm font-semibold text-zinc-300">License</h2>
              <button
                onClick={() => setShowRecent(!showRecent)}
                className="text-xs text-zinc-500 hover:text-zinc-300 transition-colors"
              >
                {showRecent ? "Hide" : "Show"} Recent ({recentGenerations.length})
              </button>
            </div>

            {showRecent && recentGenerations.length > 0 && (
              <div className="mb-4 space-y-2">
                {recentGenerations.map((item) => (
                  <button
                    key={item.id}
                    onClick={() => restoreGeneration(item)}
                    className="w-full text-left bg-black border border-zinc-800 hover:border-zinc-700 rounded-lg p-3 transition-colors"
                  >
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="text-sm text-zinc-200">{item.projectName}</div>
                        <div className="text-xs text-zinc-500">
                          {item.workflowName} · {new Date(item.createdAt).toLocaleDateString()}
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        {item.hasImage && (
                          <span className="text-xs bg-emerald-500/20 text-emerald-400 px-2 py-0.5 rounded">
                            Image
                          </span>
                        )}
                        <span className="text-xs text-zinc-600">→</span>
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            )}

            <div className="space-y-3">
              <div>
                <label className="block text-xs text-zinc-500 mb-1.5">
                  License Key (optional)
                </label>
                <input
                  type="text"
                  value={licenseKey}
                  onChange={(e) => setLicenseKey(e.target.value)}
                  placeholder="Paste your license key"
                  className="w-full bg-black border border-zinc-800 rounded-lg px-3 py-2 text-sm text-zinc-200 placeholder:text-zinc-600 focus:outline-none focus:border-zinc-600 font-mono"
                />
              </div>
              {remainingUses !== null && totalQuota !== null && (
                <div className="text-xs text-zinc-500">
                  {mode === "trial" ? "Trial" : "License"}:{" "}
                  <span className="text-zinc-300 font-medium">
                    {remainingUses} / {totalQuota}
                  </span>{" "}
                  remaining
                </div>
              )}
              <div className="flex gap-2">
                <Link
                  href="/store/web3-promo-image-factory"
                  className="text-xs text-emerald-400 hover:text-emerald-300 transition-colors"
                >
                  Buy license →
                </Link>
                <span className="text-xs text-zinc-600">
                  Free trial: 3 generations
                </span>
              </div>
            </div>
          </div>

          {/* Output */}
          {error && (
            <div className="bg-red-500/10 border border-red-500/30 text-red-400 rounded-lg p-3 text-sm">
              {error}
            </div>
          )}

          {!result && !loading && (
            <div className="bg-zinc-900/50 border border-zinc-800 border-dashed rounded-xl p-12 text-center">
              <div className="text-4xl mb-4">🖼️</div>
              <h3 className="text-lg font-medium text-zinc-300 mb-2">
                Ready to generate
              </h3>
              <p className="text-sm text-zinc-500 max-w-md mx-auto">
                Choose a workflow, fill in your project details, and click Generate.
                You&apos;ll get a prompt-ready visual pack you can use with your
                favorite image model or designer.
              </p>
            </div>
          )}

          {loading && (
            <div className="bg-zinc-900/50 border border-zinc-800 rounded-xl p-12 text-center">
              <div className="inline-block w-8 h-8 border-2 border-zinc-700 border-t-emerald-500 rounded-full animate-spin mb-4" />
              <p className="text-sm text-zinc-400">
                Generating prompts... this may take 20-40 seconds
              </p>
            </div>
          )}

          {result && !loading && (
            <div className="space-y-4">
              {imageUrl && (
                <div className="bg-zinc-900/50 border border-emerald-500/30 rounded-xl overflow-hidden">
                  <div className="px-4 py-2.5 border-b border-zinc-800 flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-medium text-emerald-400">
                        ✨ Generated Image Preview
                      </span>
                      <span className="text-xs text-zinc-500">via {providerMode}</span>
                    </div>
                    <div className="flex gap-2">
                      <a
                        href={imageUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-xs text-emerald-400 hover:text-emerald-300 transition-colors"
                      >
                        Open ↗
                      </a>
                    </div>
                  </div>
                  <img
                    src={imageUrl}
                    alt="Generated promo image"
                    className="w-full max-h-96 object-contain bg-zinc-950"
                  />
                </div>
              )}

              {!imageUrl && (
                <div className="bg-zinc-800/50 border border-zinc-700 rounded-lg p-3">
                  <p className="text-xs text-zinc-500">
                    💡 Prompt-ready output. No image provider is connected yet. Use the
                    prompt with your preferred image model or designer.
                  </p>
                </div>
              )}

              <OutputBlock
                label="🎯 Image Prompt"
                text={result.imagePrompt}
                copied={copiedField === "imagePrompt"}
                onCopy={() => copyToClipboard(result.imagePrompt, "imagePrompt")}
                lines={6}
              />

              <OutputBlock
                label="🚫 Negative Prompt"
                text={result.negativePrompt}
                copied={copiedField === "negativePrompt"}
                onCopy={() =>
                  copyToClipboard(result.negativePrompt, "negativePrompt")
                }
                lines={3}
              />

              <OutputBlock
                label="📝 Visual Brief"
                text={result.visualBrief}
                copied={copiedField === "visualBrief"}
                onCopy={() =>
                  copyToClipboard(result.visualBrief, "visualBrief")
                }
                lines={5}
              />

              <OutputBlock
                label="✏️ Headline Text"
                text={result.headlineText}
                copied={copiedField === "headlineText"}
                onCopy={() =>
                  copyToClipboard(result.headlineText, "headlineText")
                }
              />

              <OutputBlock
                label="📄 Caption Text"
                text={result.captionText}
                copied={copiedField === "captionText"}
                onCopy={() =>
                  copyToClipboard(result.captionText, "captionText")
                }
                lines={3}
              />

              <OutputBlock
                label="💡 Layout Tips"
                text={result.layoutTips
                  .map((t, i) => `${i + 1}. ${t}`)
                  .join("\n")}
                copied={copiedField === "layoutTips"}
                onCopy={() =>
                  copyToClipboard(
                    result.layoutTips.map((t, i) => `${i + 1}. ${t}`).join("\n"),
                    "layoutTips",
                  )
                }
                lines={result.layoutTips.length * 2}
              />

              <OutputBlock
                label="🔄 Variants"
                text={result.variants.map((v, i) => `${i + 1}. ${v}`).join("\n\n")}
                copied={copiedField === "variants"}
                onCopy={() => {
                  const text = result.variants
                    .map((v, i) => `${i + 1}. ${v}`)
                    .join("\n\n");
                  copyToClipboard(text, "variants");
                }}
                lines={result.variants.length * 3}
              />

              <div className="bg-zinc-800/50 border border-zinc-700 rounded-lg p-4">
                <p className="text-xs text-zinc-500 mb-2">💡 How to use</p>
                <p className="text-sm text-zinc-400">
                  Copy the Image Prompt and paste it into Midjourney, DALL-E,
                  Leonardo, Ideogram, or your preferred image model. Add text
                  overlay with Canva, Figma, or Photoshop.
                </p>
              </div>
            </div>
          )}
        </div>

        <footer className="mt-16 pt-8 border-t border-zinc-800">
          <p className="text-xs text-zinc-600 max-w-2xl">
            This tool generates marketing prompts and visual briefs.
            It does not guarantee growth, trading results, token performance,
            or financial returns. Avoid fake partnerships, fake endorsements,
            and misleading financial claims.
          </p>
        </footer>
      </div>

      {showTrialLimit && (
        <TrialLimitModal onClose={() => setShowTrialLimit(false)} />
      )}
    </main>
  );
}

function OutputBlock({
  label,
  text,
  copied,
  onCopy,
  lines = 4,
}: {
  label: string;
  text: string;
  copied: boolean;
  onCopy: () => void;
  lines?: number;
}) {
  return (
    <div className="bg-zinc-900/50 border border-zinc-800 rounded-xl overflow-hidden">
      <div className="flex items-center justify-between px-4 py-2.5 border-b border-zinc-800">
        <h3 className="text-sm font-medium text-zinc-300">{label}</h3>
        <button
          onClick={onCopy}
          className="text-xs text-zinc-500 hover:text-emerald-400 transition-colors"
        >
          {copied ? "✓ Copied" : "Copy"}
        </button>
      </div>
      <div
        className="p-4 text-sm text-zinc-300 whitespace-pre-wrap font-mono"
        style={{ minHeight: `${lines * 1.5}rem` }}
      >
        {text}
      </div>
    </div>
  );
}

function TrialLimitModal({ onClose }: { onClose: () => void }) {
  return (
    <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
      <div className="bg-zinc-900 border border-zinc-800 rounded-xl max-w-md w-full p-6">
        <div className="text-4xl mb-4">🔒</div>
        <h2 className="text-xl font-bold text-white mb-2">
          Trial limit reached
        </h2>
        <p className="text-sm text-zinc-400 mb-6">
          You&apos;ve used all 3 free generations. Purchase a license to unlock 100 generations.
        </p>
        <div className="flex gap-3">
          <button
            onClick={onClose}
            className="flex-1 border border-zinc-700 text-zinc-400 hover:text-zinc-200 py-2.5 rounded-lg transition-colors text-sm"
          >
            Close
          </button>
          <Link
            href="/checkout/web3-promo-image-factory"
            className="flex-1 bg-emerald-500 hover:bg-emerald-600 text-black font-semibold py-2.5 rounded-lg transition-colors text-sm text-center"
          >
            Buy License — 9 USDT
          </Link>
        </div>
      </div>
    </div>
  );
}
